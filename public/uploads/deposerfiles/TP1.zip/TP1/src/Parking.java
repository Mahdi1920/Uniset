public class Parking {
	public Parking() {
		
	}
}
