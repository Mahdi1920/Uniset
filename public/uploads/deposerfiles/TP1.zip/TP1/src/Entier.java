import java.util.Scanner;

	class ErrConst extends Exception{
		private int a;
		public int getA() {
			return a;
		}
		public void setA(int a) {
			this.a = a;
		}
		public ErrConst(int a){
			this.a=a;
		}
	}
	
	class ErrSom extends ErrConst{
		
		private int b;

		public int getB() {
			return b;
		}
		public void setB(int b) {
			this.b = b;
		}
		
		public ErrSom(int a, int b){
			super(a);
			this.b=b;
		}
	}
	
	class ErrDiff extends ErrConst{
		private int b;

		
		public int getB() {
			return b;
		}
		public void setB(int b) {
			this.b = b;
		}
		
		public ErrDiff(int a, int b){
			super(a);
			this.b=b;
		}
	}
	
	class ErrProd extends ErrConst{
		
		private int b;
		
		public int getB() {
			return b;
		}
		public void setB(int b) {
			this.b = b;
		}
		
		public ErrProd(int a, int b){
			super(a);
			this.b=b;
		}
	}


public class Entier {

	private int a;
	public int getA() {
		return a;
	}
	public void setA(int a) {
		this.a = a;
	}
	public Entier (int a ) throws ErrConst{
		this.a=a;
		if(a<0){
			throw new ErrConst(a);
		}}
	public static int somme(int a1, int b1) throws ErrConst,ErrSom{
		if(a1<0)throw new ErrConst(a1);
		if(a1<0)throw new ErrConst(a1);
		if(a1+b1>Integer.MAX_VALUE){
			throw new ErrSom(a1,b1);
		}
		int som=a1+b1;
		return som;
	}	
	public static int Diff(int a1, int b1) throws ErrConst,ErrDiff{
		if(a1<0)throw new ErrConst(a1);
		if(a1<0)throw new ErrConst(a1);
		int diff=a1-b1;
		if(diff<0){
			throw new ErrDiff(a1,b1);
		}
		
		return diff;
	}
	public static int produit(int a1, int b1) throws ErrConst,ErrProd{
		if(a1<0)throw new ErrConst(a1);
		if(a1<0)throw new ErrConst(a1);
		if(a1*b1>Integer.MAX_VALUE){
			throw new ErrProd(a1,b1);
		}
		int prod=a1*b1;
		return prod;
	}

	public static void main(String args[]){
		int a,b;
		Scanner sc = new Scanner(System.in);
		System.out.println("saisir a");
		a=sc.nextInt();
		System.out.println("saisir b");
		b=sc.nextInt();
		try{
			int som=Entier.somme(a,b);
			int diff=Entier.Diff(a, b);
			int prod=Entier.produit(a, b);
			
			System.out.println("somme="+som);
			System.out.println("Difference="+diff);
			System.out.println("Produit="+prod);
		}
		catch (ErrSom e){
			System.out.println("somme reached max value");
		}
		catch (ErrProd e){
			System.out.println("produit reached max value");
		}
		catch (ErrDiff e){
			System.out.println("la difference est n�gative");
		}
		catch (ErrConst e){
			System.out.println("valeur n�gative !");
		}
	}
}