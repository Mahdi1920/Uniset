import java.util.Scanner;;
public class TestDevision {
	public static void main (String[]args) {
		Scanner sc= new Scanner(System.in);
		System.out.print("saisie x: ");
		int x= sc.nextInt();
		
		System.out.print("saisie y: ");
		int y= sc.nextInt();
		
		int []tab={8,21,2,5};
		/*
		try{
			float z= x/y;
			System.out.println("la division est: "+z);
			
			for(int i=0;i<4;i++){
				System.out.println(tab[i]);
			}
		}
		catch(ArithmeticException e){
			System.out.println("Attention! Division par 0 impossible");
		}
		catch(ArrayIndexOutOfBoundsException e){
			System.out.println("Attention! index n'existe pas");
		}*/
		try{
			float z= x/y;
			System.out.println("la division est: "+z);
			
			for(int i=0;i<8;i++){
				System.out.println(tab[i]);
			}
		}
		catch(ArrayIndexOutOfBoundsException e){
			System.out.println("Attention! index n'existe pas");
		}
		catch(ArithmeticException e){
			System.out.println("Attention! Division par 0 impossible");
		}
		/*try{
			float z= x/y;
			System.out.println("la division est: "+z);
			
			for(int i=0;i<4;i++){
				System.out.println(tab[i]);
			}
		}
		catch(ArithmeticException e){
			System.out.println("Attention! Division par 0 impossible");
		}
				finally {
			System.out.println("Attention! index n'existe pas");
		}*/

		/*try{
				float z= x/y;
				System.out.println("la division est: "+z);
			}
		
		catch(ArithmeticException e){
			System.out.println("Attention! Division par 0 impossible");
		}
		try{
				for(int i=0;i<4;i++){
				System.out.println(tab[i]);
			}
		}
		catch(ArrayIndexOutOfBoundsException e){
			System.out.println("Attention! index n'existe pas");
		}*/

	}
}
