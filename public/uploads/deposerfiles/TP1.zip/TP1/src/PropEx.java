
public class PropEx {
	
		 public static void main(String[] args) {
		 System.out.println("main commence");
		 //b(5);
		 b(0);
		 System.out.println("main termine");
		 }
		 //---------------------------------------------
		 // b
		 //---------------------------------------------
		 public static void b(int i) {
		 System.out.println("b commence");
		 try {
		 System.out.println("b �tape 1");
		 c(i);
		 System.out.println("b �tape 2");
		 }
		 catch (Exception e) {
		 System.out.println("b intercepte " + e);
		 }
		 System.out.println("b termine ");
		 }
		 //---------------------------------------------
		 // c
		 //---------------------------------------------
		 public static void c(int i) throws Exception {
		 System.out.println("c commence");
		 d(i);
		 System.out.println("c termine");
		 }
		 //---------------------------------------------
		 // d
		 //---------------------------------------------
		public static void d(int i) throws Exception {
		 System.out.println("d commence");
		 int a=10/i; // Cette instruction peut g�n�rer une
		// exception
		 System.out.println("d termine");
		}
		 }

