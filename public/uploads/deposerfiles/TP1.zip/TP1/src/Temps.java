import java.util.Scanner;
class TempsException extends Exception{
	 public TempsException() {
		    super();
		  }

		  public TempsException(String s) {
		    super(s);
		  }
}
public class Temps {
	private int heures;
	private int minutes;
	private int secondes; 
	
	public int getHeures() {
		return heures;
	}
	public void setHeures(int heures) {
		this.heures = heures;
	}
	public int getMinutes() {
		return minutes;
	}
	public void setMinutes(int minutes) {
		this.minutes = minutes;
	}
	public int getSecondes() {
		return secondes;
	}
	public void setSecondes(int secondes) {
		this.secondes = secondes;
	}
	
	public Temps (int h, int m, int s)throws TempsException{ 
		 heures = h; 
		 minutes = m; 
		 secondes = s;
		 if (h<0 ||h>=24||m<0||m>=60||s<0||s>=60){
			 throw new TempsException("Temps invalide!");
		 }
	}
	
	public static void main(String args[]) throws TempsException{
		int h,m,s;  
		Scanner sc= new Scanner(System.in);
		System.out.print("saisie heure: ");
			h= sc.nextInt();
		System.out.print("saisie les minutes: ");
			m= sc.nextInt();    
		System.out.print("saisie secondes: ");
		 	s= sc.nextInt();
		
	try {
		Temps t =new Temps(h,m,s);
		System.out.println(h+":"+m+":"+s);
		}
	catch(TempsException e)
		{
		System.out.println("temps invalide");
		}
	}
	}
